package com.example.fxmlplayer;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Slider;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;

import java.util.Objects;

public class Controller {

    public Slider durationBar;
    public Slider volumeBar;
    @FXML
    private MediaView mediaView;
    private MediaPlayer player;

    @FXML
    public void initialize() {
        String video = Objects.requireNonNull(getClass().getResource("crushing_snakes.mp4")).toExternalForm();
        Media media = new Media(video);
        player = new MediaPlayer(media);
        mediaView.setMediaPlayer(player);
    }

    @FXML
    void playVideo(MouseEvent event) {
        player.play();
    }

    @FXML
    void stopVideo(MouseEvent event) {
        player.stop();
    }

    @FXML
    void exitApplication(MouseEvent event) {
        Platform.exit();
    }

    public void openPreferences(MouseEvent mouseEvent) {
    }

    public void openEqualizer(MouseEvent mouseEvent) {
    }

    public void openPlaylist(MouseEvent mouseEvent) {
    }

    public void minimizeApplication(MouseEvent mouseEvent) {
    }


}
